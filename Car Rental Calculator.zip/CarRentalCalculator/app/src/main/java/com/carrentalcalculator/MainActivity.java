package com.carrentalcalculator;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    Spinner carType;
    EditText dailyPrice, days, subTotal, tax, total;
    Button submit, reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        carType = findViewById(R.id.car_type);
        dailyPrice = findViewById(R.id.daily_price);
        days = findViewById(R.id.days);
        subTotal = findViewById(R.id.sub_total);
        tax = findViewById(R.id.tax);
        total = findViewById(R.id.total);
        submit = findViewById(R.id.submit);
        reset = findViewById(R.id.reset);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.cars, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        carType.setAdapter(adapter);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String error = validate();
                if (error.isEmpty()) {
                    calculate();
                } else {
                    showError(error);
                }
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                carType.setSelection(0);
                dailyPrice.setText("");
                days.setText("");
                subTotal.setText("");
                tax.setText("");
                total.setText("");
            }
        });
    }

    private void calculate() {
        double price = Double.parseDouble(this.dailyPrice.getText().toString());
        double dailyExpenditure = (price + price); // insurance price is same as of daily price.
        double subTotal = dailyExpenditure * Integer.parseInt(days.getText().toString());
        double tax = (subTotal * 13) / 100;
        double total = subTotal + tax;
        this.subTotal.setText(String.format("%.2f", subTotal));
        this.tax.setText(String.format("%.2f", tax));
        this.total.setText(String.format("%.2f", total));

    }

    private String validate() {
        String error = "";
        if (carType.getSelectedItemPosition() == 0) {
            error = "Please select car type";
        } else if (dailyPrice.getText().toString().isEmpty()) {
            error = "Please add daily price";
        } else if (days.getText().toString().isEmpty()) {
            error = "Please enter number of days";
        }
        return error;
    }

    private void showError(String error) {
        new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(error)
                .setPositiveButton(android.R.string.ok, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }
}
